public class Testandrun {
    public static void main(String[] args) {
        Spiel s = new Spiel();
        
    }
}